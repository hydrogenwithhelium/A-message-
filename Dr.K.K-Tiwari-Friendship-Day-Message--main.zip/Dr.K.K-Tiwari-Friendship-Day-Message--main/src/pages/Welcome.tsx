import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import TypewriterText from '@/components/TypewriterText';

const Welcome = () => {
  const [showNextButton, setShowNextButton] = useState(false);
  const navigate = useNavigate();

  const handleTypewriterComplete = () => {
    setShowNextButton(true);
  };

  const handleNext = () => {
    navigate('/question');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-8">
      <div className="text-center max-w-2xl">
        <h1 className="text-4xl md:text-5xl font-bold mb-8 text-foreground">
          Hi HAPPY FRIENDSHIP DAY 🙏🏻🦚✨️
        </h1>
        
        <div className="text-xl md:text-2xl mb-12 text-foreground">
          <TypewriterText
            text="Hey, I am... you know who I am :)"
            speed={80}
            onComplete={handleTypewriterComplete}
          />
        </div>

        {showNextButton && (
          <Button 
            onClick={handleNext}
            className="px-8 py-3 text-lg animate-fade-in"
            variant="default"
          >
            Next
          </Button>
        )}
      </div>
    </div>
  );
};

export default Welcome;