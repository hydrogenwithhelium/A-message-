import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog';

const Question = () => {
  const [showPopup, setShowPopup] = useState(false);
  const [popupMessage, setPopupMessage] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [hasChosen, setHasChosen] = useState(false);

  const handleYes = () => {
    setHasChosen(true);
    setPopupMessage("Thank You 😊 🙏🏽... Will not disturb you again");
    setIsOpen(true);
    setShowPopup(true);
  };

  const handleNo = () => {
    setHasChosen(true);
    setPopupMessage(`Hey... 😀 yes you... your late night messages or messages at any time, whether it's your photo, video, any questions, or even YouTube links... makes me happy 😊 .. You are more than a friend for me 😉

Today is 3rd August, Friendship Day... yesterday was 2nd August... 1 month from the day we got introduced to each other... 👀

From calling you a surprise 🫠... & from wrong address to Blinkit chaos 😭... while in silence, I created your 2D artwork 😌 & reading your book 🫡...

If sometimes due to my bad humor messages you got hurt, then sorry prabhu 😁

If you see this message, please send me a message (aree haa mujhe hi) - send this message: "Oye kya haal hai"

And if you don't send this message, then I'll understand that you didn't reach this page or I'll do even worse overthinking 🥲`);
    setIsOpen(true);
    setShowPopup(true);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-8">
      <div className="text-center max-w-2xl">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-foreground">
          Am I annoying? 😑
        </h1>
        
        <p className="text-lg mb-8 text-muted-foreground font-poppins">
          Choose carefully kariyegaa.. , ek baar choose ke baad dubura re attempt nhi kar paayenge ..
        </p>
        
        <div className="flex gap-6 justify-center">
          <Button 
            onClick={handleYes}
            disabled={hasChosen}
            className="px-8 py-3 text-lg bg-black text-white hover:bg-black/80 disabled:opacity-50"
          >
            Yes
          </Button>
          
          <Button 
            onClick={handleNo}
            disabled={hasChosen}
            className="px-8 py-3 text-lg bg-black text-white hover:bg-black/80 disabled:opacity-50"
          >
            No
          </Button>
        </div>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto font-poppins">
          <DialogTitle className="sr-only">Message</DialogTitle>
          <DialogDescription className="text-foreground text-lg whitespace-pre-line leading-relaxed font-poppins">
            {popupMessage}
          </DialogDescription>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Question;